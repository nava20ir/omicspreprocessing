## 📦 PyPI
- For documentation refer to

https://omicspreprocessing.readthedocs.io/en/latest/omicspreprocessing.html

You can install this package via pip:

```bash
pip install omicspreprocessing
```

or first clone the package and then

```
pip install -e .


```
